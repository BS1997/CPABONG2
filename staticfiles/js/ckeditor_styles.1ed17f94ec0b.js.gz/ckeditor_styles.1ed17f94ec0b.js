CKEDITOR.stylesSet.add('my_styles', [
    {
        name: '제목 스타일',
        element: 'h3',
        styles: {
            'border-left': '4px solid #ccc',
            'padding-left': '10px',
            'margin': '20px 0',
            'font-weight': 'bold'
        }
    }
]);